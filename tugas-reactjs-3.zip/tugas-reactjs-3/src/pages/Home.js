import React from 'react';
import ErrorBoundary from '../components/ErrorBoundary';

const Home = () => {
  return (
    <div className='App'>
      <header className='App-header'>
        <h1>Ini Halaman Home</h1>
      </header>
      <main>
        <a href='/product'><button>ke halaman product</button></a>
        <section className='products'>
          <ErrorBoundary></ErrorBoundary>
        </section>
        <footer></footer>
      </main>
    </div>
  );
};

export default Home;
