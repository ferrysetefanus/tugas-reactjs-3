export const productList_DUMMY = [
  {
    id: 1,
    title: 'Rinso',
    price: 23000,
  },
  {
    id: 2,
    title: 'WPC',
    price: 12000,
  },
  {
    id: 3,
    title: 'Coca Cola',
    price: 5000,
  },
  {
    id: 4,
    title: 'Mie Sedap',
    price: 2700,
  },
  {
    id: 5,
    title: 'Wafer Chocolatos',
    price: 8000,
  },
];
