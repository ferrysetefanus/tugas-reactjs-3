import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import NotFound from './pages/NotFound';
import ProductsPage from './pages/ProductPage';

function App() {
  return (
    <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/product' element={<ProductsPage />} />
      <Route path='*' element={<NotFound />} />
    </Routes>
  );
}

export default App;
